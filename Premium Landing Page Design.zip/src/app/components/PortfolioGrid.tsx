import { motion } from 'motion/react';
import { useState } from 'react';

interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  image: string;
}

const portfolioItems: PortfolioItem[] = [
  {
    id: 1,
    title: "Urban Architecture",
    category: "Branding",
    image: "https://images.unsplash.com/photo-1681216868987-b7268753b81c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBkZXNpZ258ZW58MXx8fHwxNzY3MjE3ODMwfDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 2,
    title: "Brand Identity",
    category: "Design",
    image: "https://images.unsplash.com/photo-1730889244771-2270882b2600?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGJyYW5kaW5nJTIwbWluaW1hbHxlbnwxfHx8fDE3NjcyOTc4MzR8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 3,
    title: "Product Vision",
    category: "3D Design",
    image: "https://images.unsplash.com/photo-1629134287416-1403dd88b791?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMHByb2R1Y3QlMjBkZXNpZ258ZW58MXx8fHwxNzY3Mjk3ODM1fDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 4,
    title: "Mobile Experience",
    category: "UI/UX",
    image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjB1aSUyMGludGVyZmFjZXxlbnwxfHx8fDE3NjcyOTc4MzV8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 5,
    title: "Creative Workspace",
    category: "Branding",
    image: "https://images.unsplash.com/photo-1609921212029-bb5a28e60960?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFwaGljJTIwZGVzaWduJTIwd29ya3NwYWNlfGVufDF8fHx8MTc2NzIzNDExOHww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 6,
    title: "Web Interface",
    category: "Development",
    image: "https://images.unsplash.com/photo-1676799910963-3932099f67e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwd2ViJTIwZGVzaWdufGVufDF8fHx8MTc2NzI1MzExM3ww&ixlib=rb-4.1.0&q=80&w=1080"
  }
];

export function PortfolioGrid() {
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  return (
    <section className="py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="mb-4 bg-gradient-to-r from-cyan-400 to-fuchsia-400 bg-clip-text text-transparent">
            Featured Work
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto">
            Explore our latest projects that showcase innovation and creativity
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portfolioItems.map((item, index) => (
            <motion.div
              key={item.id}
              className="relative aspect-[4/5] rounded-2xl overflow-hidden cursor-pointer group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              onMouseEnter={() => setHoveredId(item.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Image */}
              <div className="absolute inset-0">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />

              {/* Content */}
              <div className="absolute inset-0 p-6 flex flex-col justify-end">
                <motion.div
                  initial={false}
                  animate={{
                    y: hoveredId === item.id ? 0 : 20,
                    opacity: hoveredId === item.id ? 1 : 0.8
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <span className="text-cyan-400 text-sm mb-2 block">
                    {item.category}
                  </span>
                  <h3 className="text-white">
                    {item.title}
                  </h3>
                </motion.div>

                {/* Hover indicator */}
                <motion.div
                  className="absolute top-6 right-6 w-12 h-12 rounded-full border-2 border-white/30 flex items-center justify-center"
                  initial={false}
                  animate={{
                    scale: hoveredId === item.id ? 1 : 0,
                    opacity: hoveredId === item.id ? 1 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="w-6 h-0.5 bg-white" />
                </motion.div>
              </div>

              {/* Border glow effect */}
              <div 
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  boxShadow: '0 0 30px rgba(6, 182, 212, 0.5)',
                }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
