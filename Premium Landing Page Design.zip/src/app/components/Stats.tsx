import { motion } from 'motion/react';

interface Stat {
  value: string;
  label: string;
  suffix?: string;
}

const stats: Stat[] = [
  { value: '500', label: 'Happy Clients', suffix: '+' },
  { value: '1200', label: 'Projects Completed', suffix: '+' },
  { value: '98', label: 'Client Satisfaction', suffix: '%' },
  { value: '15', label: 'Years Experience', suffix: '+' }
];

export function Stats() {
  return (
    <section className="py-20 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              className="text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div className="relative inline-block mb-3">
                <motion.h2
                  className="bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-yellow-400 bg-clip-text text-transparent"
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 + 0.2 }}
                >
                  {stat.value}{stat.suffix}
                </motion.h2>
                {/* Glow effect */}
                <div className="absolute inset-0 blur-2xl bg-gradient-to-r from-cyan-500/20 via-fuchsia-500/20 to-yellow-500/20" />
              </div>
              <p className="text-white/60 text-sm">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
