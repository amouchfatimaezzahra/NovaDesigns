import { motion } from 'motion/react';
import { Sparkles, Layers, Zap } from 'lucide-react';

interface Service {
  id: number;
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
}

const services: Service[] = [
  {
    id: 1,
    icon: <Sparkles className="w-8 h-8" />,
    title: "Brand Identity",
    description: "Crafting unique visual identities that resonate with your audience and stand the test of time.",
    features: ["Logo Design", "Brand Guidelines", "Visual Strategy"]
  },
  {
    id: 2,
    icon: <Layers className="w-8 h-8" />,
    title: "UI/UX Design",
    description: "Creating intuitive and beautiful interfaces that deliver exceptional user experiences.",
    features: ["Web Design", "Mobile Apps", "Prototyping"]
  },
  {
    id: 3,
    icon: <Zap className="w-8 h-8" />,
    title: "Development",
    description: "Building robust, scalable solutions with cutting-edge technologies and best practices.",
    features: ["Web Development", "E-commerce", "Custom Solutions"]
  }
];

export function Services() {
  return (
    <section className="py-32 px-6 relative">
      {/* Background gradient orbs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-fuchsia-500/10 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="mb-4 bg-gradient-to-r from-fuchsia-400 to-yellow-400 bg-clip-text text-transparent">
            Our Services
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto">
            Comprehensive solutions tailored to bring your vision to life
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              className="group relative"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              {/* Glassmorphism card */}
              <div className="relative h-full p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300 group-hover:bg-white/10">
                {/* Gradient overlay on hover */}
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-cyan-500/5 via-fuchsia-500/5 to-yellow-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <div className="relative z-10">
                  {/* Icon */}
                  <motion.div
                    className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-fuchsia-500 flex items-center justify-center text-white mb-6"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  >
                    {service.icon}
                  </motion.div>

                  {/* Content */}
                  <h3 className="text-white mb-4">
                    {service.title}
                  </h3>
                  <p className="text-white/60 mb-6">
                    {service.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-3">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-3 text-white/70">
                        <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-400" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  {/* Hover effect - Learn more */}
                  <motion.div
                    className="mt-6 pt-6 border-t border-white/10"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                  >
                    <button className="text-cyan-400 hover:text-cyan-300 transition-colors text-sm group/btn flex items-center gap-2">
                      Learn More
                      <motion.span
                        className="inline-block"
                        animate={{ x: [0, 5, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        →
                      </motion.span>
                    </button>
                  </motion.div>
                </div>

                {/* Glow effect */}
                <div className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                  <div className="absolute inset-0 rounded-3xl shadow-2xl shadow-cyan-500/20" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
