import { motion } from 'motion/react';
import logo from 'figma:asset/301dab11e16ed712ed73a2e31fd61658739d869f.png';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    Company: ['About', 'Services', 'Work', 'Careers'],
    Resources: ['Blog', 'Case Studies', 'Testimonials', 'FAQ'],
    Social: ['Twitter', 'LinkedIn', 'Instagram', 'Dribbble']
  };

  return (
    <footer className="relative py-20 px-6 border-t border-white/10">
      {/* Background gradient */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50" />

      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <motion.div
              className="flex items-center gap-3 mb-4"
              whileHover={{ scale: 1.02 }}
            >
              <img src={logo} alt="NovaDesign" className="h-14 w-auto" />
            </motion.div>
            <p className="text-white/60 mb-6 max-w-xs">
              Crafting exceptional digital experiences that push boundaries and elevate brands.
            </p>
            <div className="flex gap-4">
              {['Tw', 'In', 'Ig', 'Dr'].map((social, index) => (
                <motion.div
                  key={social}
                  className="w-10 h-10 rounded-lg bg-white/5 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 hover:border-white/20 cursor-pointer transition-all duration-300"
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {social}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-white mb-4">{category}</h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-white/60 hover:text-white transition-colors text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-sm">
            © {currentYear} NovaDesign. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-white/40 hover:text-white transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-white/40 hover:text-white transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}